---
name: "SkillBridge — Neon Underground"
description: "Dark-mode, neo-brutalist Swiss editorial design system for SkillBridge, a campus peer-to-peer micro-learning and doubt-solving network."
---

## Overview

SkillBridge is the underground knowledge network of an engineering campus—where skills are currency, helping is status, and nobody stays stuck alone. The visual language is **Neon Underground**: inspired by modern dark-mode developer tools, experimental Swiss typography, neo-brutalist digital interfaces, and minimal futuristic operating systems.

The interface prioritizes usability, scanability, and technical credibility over decoration. It feels bold, intelligent, technical, youthful, and experimental—like a funded early-stage developer tool—while strictly avoiding excessive glassmorphism, purple/blue SaaS gradients, cartoon illustrations, or gaming-scoreboard clichés.

### Do's and Don'ts
- **Do** keep 75% of every screen in deep dark neutral surfaces (`#080A09`, `#101410`, `#151B15`), 15% in high-contrast typography and hairline borders, and 10% in acid-lime neon accents (`#C6FF3D`, `#91FF69`).
- **Do** use neon lime exclusively for primary actions, active states, key statistics, status dots, and progress indicators.
- **Do** pair oversized Space Grotesk editorial headings with crisp JetBrains Mono metadata (`tabular-nums`, timestamps, IDs, karma counts).
- **Do** use inline Lucide-style `<svg>` icons (`stroke="currentColor"`, `stroke-width="1.75"`, `stroke-linecap="round"`, `stroke-linejoin="round"`).
- **Don't** use neon lime as a large background covering entire sections.
- **Don't** introduce purple, blue, or pink gradients, heavy drop shadows, `backdrop-blur` glassmorphism, or decorative pulsing dots that signify nothing.
- **Don't** use Material Symbols or emoji as icons.

## Colors

A strict black and acid-lime palette. Deep carbon-moss blacks eliminate halation while razor-sharp acid lime guides attention to active sessions, bounties, and primary CTAs.

- **Primary (`#C6FF3D`)**: Acid lime for primary CTAs, active navigation markers, match scores, and key metrics. Paired with `#080A09` text.
- **Secondary (`#91FF69`)**: Electric mint-lime for resolved states, verified helper badges, and live availability indicators.
- **Surfaces (`#080A09` → `#101410` → `#151B15`)**: Three-tier dark neutral hierarchy with `1px` `#293229` structural borders.
- **Status (`#FF6262`, `#FFCB65`)**: Reserved strictly for error/urgent states and warning/intermediate indicators.

```yaml
colors:
  primary: "#C6FF3D"
  on-primary: "#080A09"
  primary-container: "#263500"
  on-primary-container: "#D7FF81"
  secondary: "#91FF69"
  on-secondary: "#080A09"
  surface: "#080A09"
  on-surface: "#F4F7EF"
  surface-container-low: "#101410"
  surface-container: "#151B15"
  surface-container-high: "#1D251D"
  on-surface-variant: "#9AA397"
  on-surface-muted: "#7E887B"
  outline: "#293229"
  outline-variant: "#1D241D"
  error: "#FF6262"
  on-error: "#080A09"
  warning: "#FFCB65"
  on-warning: "#080A09"
  success: "#91FF69"
  on-success: "#080A09"
```

## Typography

Three Google Font families establish clear contrast between oversized editorial statements, dense readable UI, and technical metadata:

- **Space Grotesk (`headline`)**: Display statements, page headers, and major numeric KPIs.
- **Inter (`body`)**: Interface copy, doubt descriptions, form labels, and navigation.
- **JetBrains Mono (`mono`)**: Skill tags, timestamps, session timers, IDs, karma credits, and status badges.

All icons are inline Lucide-style SVGs (`w-4 h-4` or `w-5 h-5`, `stroke-width="1.75"`).

```yaml
typography:
  display-lg:
    fontFamily: "Space Grotesk"
    fontSize: 64px
    fontWeight: 700
    lineHeight: 68px
    letterSpacing: -2px
  display-lg-mobile:
    fontFamily: "Space Grotesk"
    fontSize: 32px
    fontWeight: 700
    lineHeight: 36px
    letterSpacing: -1px
  display-md:
    fontFamily: "Space Grotesk"
    fontSize: 44px
    fontWeight: 700
    lineHeight: 48px
    letterSpacing: -1.5px
  display-md-mobile:
    fontFamily: "Space Grotesk"
    fontSize: 28px
    fontWeight: 700
    lineHeight: 32px
    letterSpacing: -0.75px
  headline-lg:
    fontFamily: "Space Grotesk"
    fontSize: 32px
    fontWeight: 700
    lineHeight: 38px
    letterSpacing: -0.75px
  headline-md:
    fontFamily: "Space Grotesk"
    fontSize: 24px
    fontWeight: 600
    lineHeight: 30px
    letterSpacing: -0.5px
  headline-sm:
    fontFamily: "Space Grotesk"
    fontSize: 18px
    fontWeight: 600
    lineHeight: 24px
    letterSpacing: -0.25px
  body-lg:
    fontFamily: "Inter"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 24px
    letterSpacing: 0px
  body-md:
    fontFamily: "Inter"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 20px
    letterSpacing: 0px
  body-sm:
    fontFamily: "Inter"
    fontSize: 12px
    fontWeight: 400
    lineHeight: 18px
    letterSpacing: 0px
  label-lg:
    fontFamily: "Inter"
    fontSize: 14px
    fontWeight: 600
    lineHeight: 20px
    letterSpacing: 0px
  label-md:
    fontFamily: "Inter"
    fontSize: 12px
    fontWeight: 500
    lineHeight: 16px
    letterSpacing: 0.25px
  mono-lg:
    fontFamily: "JetBrains Mono"
    fontSize: 20px
    fontWeight: 700
    lineHeight: 24px
    letterSpacing: -0.5px
  mono-md:
    fontFamily: "JetBrains Mono"
    fontSize: 12px
    fontWeight: 500
    lineHeight: 16px
    letterSpacing: 0.25px
  mono-sm:
    fontFamily: "JetBrains Mono"
    fontSize: 11px
    fontWeight: 500
    lineHeight: 14px
    letterSpacing: 0.5px
```

## Layout & Spacing

Built on a strict **8px spacing system** (with a 4px half-step for micro-alignment). Desktop screens use a persistent `240px` left sidebar and fluid main canvas (`max-w-[1440px]`), collapsing to a compact top bar and bottom navigation on mobile (`390px`). Subtle `24px` technical grid backgrounds may be used sparingly behind hero or canvas zones.

```yaml
spacing:
  gutter-xs: 4px
  gutter-sm: 8px
  gutter-md: 16px
  gutter-lg: 24px
  gutter-xl: 32px
  section: 48px
  page-margin: 24px
```

## Elevation & Depth

SkillBridge uses **tonal surface steps** (`#080A09` → `#101410` → `#151B15`) paired with crisp `1px` `#293229` borders rather than heavy drop shadows. Interactive cards reveal a `#C6FF3D` border on hover, and primary neon buttons emit a restrained `0 0 20px rgba(198, 255, 61, 0.22)` glow on hover.

## Shapes

Sharp or moderately rounded technical geometry. Cards and inputs use `4px`–`8px` corners; status pills and skill tags use `2px`–`4px` corners for a Swiss-technical feel, reserving `9999px` for avatars and live status dots.

```yaml
rounded:
  none: 0px
  xs: 2px
  sm: 4px
  DEFAULT: 6px
  md: 8px
  lg: 12px
  full: 9999px
```

## Motion & Micro-interaction

Motion is crisp, mechanical, and restrained. Hovering cards shifts border color to primary neon within `120ms`. Primary buttons gain a subtle lime glow. Active status dots pulse gently. Skeleton loaders use minimal flat surface sweeps.

```yaml
motion:
  state-change:
    duration: 120ms
    delay: 0ms
    timingFunction: cubic-bezier(0.2, 0, 0, 1)
  surface-enter:
    duration: 200ms
    delay: 0ms
    timingFunction: cubic-bezier(0.2, 0, 0, 1)
  surface-exit:
    duration: 140ms
    delay: 0ms
    timingFunction: cubic-bezier(0.3, 0, 1, 1)
```

## Voice & Content Strategy

- **Tone**: Direct, technical, peer-to-peer, and encouraging without fluff. Write like sharp engineering students helping each other debug at 11 PM.
- **Capitalisation**: Uppercase `Space Grotesk` for major editorial headlines and `JetBrains Mono` micro-labels (`CAMPUS NETWORK / 001`, `STATUS: OPEN`). Sentence case for descriptions and body copy.
- **Action Labels**: Specific verb phrases (`POST A DOUBT`, `CLAIM SESSION`, `PUBLISH DOUBT`, `REQUEST SESSION`, `MARK RESOLVED`).
- **Realism**: Believable Indian engineering campus names, courses, and technical problems (C++ pointers, React hooks, SolidWorks constraints, Engineering Mathematics).

## Components

Component implementations live as individual HTML sticker sheet files in
`components/`. Each file contains the canonical, styled HTML components with
`<!-- COMPONENT: name -->` comment markers. Read each file before use.

- **Badge** → `@components/badge.html`: `badge-numeric`, `badge-dot`
- **Button** → `@components/button.html`: `button-primary`, `button-icon`, `button-with-icon`
- **Card** → `@components/card.html`: `card-elevated`, `card-action`, `card-interactive`, `card-interactive-2`
- **Chip** → `@components/chip.html`: `chip-action`, `chip-input`, `chip-with-icon`
- **Input Field** → `@components/input-field.html`: `input-field-text`, `input-field-icon`
